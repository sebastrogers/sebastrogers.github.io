API=https://SEU-ID.execute-api.us-east-1.amazonaws.com
for i in $(seq 1 30); do
  curl -s -o /dev/null -w "%{http_code}\n" \
       -H "x-api-key: loja-turma-2026" "$API/produtos"
done | sort | uniq -c
