import json
import os

CHAVE = os.environ.get("CHAVE_LOJA", "")   # configurada no console

PRODUTOS = [
    {"id": 1, "nome": "Camiseta básica", "preco": 39.90, "tamanho": "M"},
    {"id": 2, "nome": "Calça jeans", "preco": 129.90, "tamanho": "G"},
    {"id": 3, "nome": "Moletom", "preco": 159.90, "tamanho": "P"},
]
FRETE_FIXO = 15.0
FRETE_GRATIS_A_PARTIR_DE = 200.0


def frete(valor):
    if valor >= FRETE_GRATIS_A_PARTIR_DE:
        return 0.0
    return FRETE_FIXO


def resposta(status, dados):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(dados, ensure_ascii=False),
    }


def chave_valida(event):
    cabecalhos = event.get("headers") or {}
    return CHAVE != "" and cabecalhos.get("x-api-key") == CHAVE


def lambda_handler(event, context):
    rota = event.get("routeKey")
    print("pedido:", rota)

    if not chave_valida(event):
        return resposta(401, {"erro": "chave ausente ou inválida"})

    if rota == "GET /produtos":
        return resposta(200, PRODUTOS)

    if rota == "POST /carrinho/total":
        itens = json.loads(event.get("body") or "[]")
        precos = {p["id"]: p["preco"] for p in PRODUTOS}
        subtotal = sum(precos[i["id"]] * i["quantidade"] for i in itens)
        return resposta(200, {
            "subtotal": round(subtotal, 2),
            "frete": frete(subtotal),
            "total": round(subtotal + frete(subtotal), 2),
        })

    if rota == "GET /promocoes":
        return resposta(200, [{"produto_id": 3, "desconto": "10%"}])

    return resposta(404, {"erro": "rota não encontrada"})
