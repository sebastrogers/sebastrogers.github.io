import json

PRODUTOS = [
    {"id": 1, "nome": "Camiseta básica", "preco": 39.90, "tamanho": "M"},
    {"id": 2, "nome": "Calça jeans", "preco": 129.90, "tamanho": "G"},
    {"id": 3, "nome": "Moletom", "preco": 159.90, "tamanho": "P"},
]
FRETE_FIXO = 15.0
FRETE_GRATIS_A_PARTIR_DE = 200.0


def frete(valor):
    if valor >= FRETE_GRATIS_A_PARTIR_DE:
        return 0.0
    return FRETE_FIXO


def resposta(status, dados):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(dados, ensure_ascii=False),
    }


def lambda_handler(event, context):
    rota = event.get("routeKey")        # ex.: "GET /produtos"
    print("pedido:", rota)              # aparece no CloudWatch

    if rota == "GET /produtos":
        return resposta(200, PRODUTOS)

    if rota == "POST /carrinho/total":
        itens = json.loads(event.get("body") or "[]")
        precos = {p["id"]: p["preco"] for p in PRODUTOS}
        subtotal = sum(precos[i["id"]] * i["quantidade"] for i in itens)
        return resposta(200, {
            "subtotal": round(subtotal, 2),
            "frete": frete(subtotal),
            "total": round(subtotal + frete(subtotal), 2),
        })

    return resposta(404, {"erro": "rota não encontrada"})
