import json

PRODUTOS = [
    {"id": 1, "nome": "Camiseta básica", "preco": 39.90, "tamanho": "M"},
    {"id": 2, "nome": "Calça jeans", "preco": 129.90, "tamanho": "G"},
    {"id": 3, "nome": "Moletom", "preco": 159.90, "tamanho": "P"},
]


def resposta(status, dados):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(dados, ensure_ascii=False),
    }


def lambda_handler(event, context):
    return resposta(200, PRODUTOS)
