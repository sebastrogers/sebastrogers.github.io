import json
import os
from decimal import Decimal

import boto3
from botocore.exceptions import ClientError

CHAVE = os.environ.get("CHAVE_LOJA", "")
TABELA = os.environ.get("TABELA_PRODUTOS", "loja-produtos")
tabela = boto3.resource("dynamodb").Table(TABELA)   # criado uma vez, fora do handler

FRETE_FIXO = Decimal("15.0")
FRETE_GRATIS_A_PARTIR_DE = Decimal("200.0")


def para_json(valor):
    """O DynamoDB devolve Decimal; o JSON não conhece."""
    if isinstance(valor, Decimal):
        return int(valor) if valor % 1 == 0 else float(valor)
    raise TypeError(type(valor))


def resposta(status, dados):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(dados, ensure_ascii=False, default=para_json),
    }


def chave_valida(event):
    cabecalhos = event.get("headers") or {}
    return CHAVE != "" and cabecalhos.get("x-api-key") == CHAVE


def corpo(event):
    return json.loads(event.get("body") or "{}", parse_float=Decimal)


def lambda_handler(event, context):
    rota = event.get("routeKey")
    print("pedido:", rota)

    if not chave_valida(event):
        return resposta(401, {"erro": "chave ausente ou inválida"})

    if rota == "GET /produtos":
        itens = tabela.scan()["Items"]
        return resposta(200, sorted(itens, key=lambda p: p["id"]))

    if rota == "GET /produtos/{id}":
        produto_id = int(event["pathParameters"]["id"])
        item = tabela.get_item(Key={"id": produto_id}).get("Item")
        if item is None:
            return resposta(404, {"erro": "produto não encontrado"})
        return resposta(200, item)

    if rota == "POST /produtos":
        dados = corpo(event)
        if dados.get("preco", 0) <= 0 or not dados.get("nome"):
            return resposta(422, {"erro": "nome e preço positivo"})
        try:
            tabela.put_item(
                Item=dados,
                ConditionExpression="attribute_not_exists(id)",
            )
        except ClientError as erro:
            codigo = erro.response["Error"]["Code"]
            if codigo == "ConditionalCheckFailedException":
                return resposta(409, {"erro": "id já cadastrado"})
            raise
        return resposta(201, dados)

    if rota == "POST /carrinho/total":
        itens = json.loads(event.get("body") or "[]")
        subtotal = Decimal("0")
        for item in itens:
            produto = tabela.get_item(Key={"id": item["id"]}).get("Item")
            if produto is None:
                return resposta(404, {"erro": f"produto {item['id']} não encontrado"})
            subtotal += produto["preco"] * item["quantidade"]
        frete = Decimal("0") if subtotal >= FRETE_GRATIS_A_PARTIR_DE else FRETE_FIXO
        return resposta(200, {"subtotal": subtotal, "frete": frete, "total": subtotal + frete})

    return resposta(404, {"erro": "rota não encontrada"})
