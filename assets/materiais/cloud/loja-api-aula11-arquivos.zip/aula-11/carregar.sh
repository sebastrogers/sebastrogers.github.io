#!/usr/bin/env bash
# Rode no CloudShell, na mesma pasta do itens.json
aws dynamodb create-table \
  --table-name loja-produtos \
  --attribute-definitions AttributeName=id,AttributeType=N \
  --key-schema AttributeName=id,KeyType=HASH \
  --billing-mode PAY_PER_REQUEST

aws dynamodb wait table-exists --table-name loja-produtos
aws dynamodb batch-write-item --request-items file://itens.json
aws dynamodb scan --table-name loja-produtos --output table
