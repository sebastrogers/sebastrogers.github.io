"""Prática 1: variáveis, atribuição múltipla e troca de valores.  (8 min)

Rode com:  python pratica1_variaveis.py
"""

# TODO 0. Crie curso, semestre e turno EM UMA ÚNICA LINHA,
#         com os valores "ADS", 2 e "noite".


# TODO 1. Imprima os três, separados por espaço.


# TODO 2. Troque o valor de curso e turno de lugar,
#         SEM usar variável auxiliar. Imprima de novo.


# TODO 3. Atribua 0 a três contadores diferentes em uma linha só,
#         e imprima os três.


# TODO 4. Descomente a linha abaixo, rode, e anote a mensagem de erro.
# for = 10
