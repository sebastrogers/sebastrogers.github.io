"""Prática 5: a comanda do domínio da SUA equipe.  (20 min)

Se a sua equipe não é de barbearia, troque os serviços pelos itens
do seu catálogo e a regra de desconto pela regra da sua equipe.

Rode com:  python pratica5_comanda.py
"""

from decimal import Decimal

# TODO 0. Monte um dicionário precos com QUATRO itens do seu catálogo.
#         Os valores devem ser Decimal("35.00"), e não 35.00.


# TODO 1. Monte uma lista comanda com o que o cliente consumiu,
#         repetindo pelo menos um item.
#         Inclua DE PROPÓSITO um item que não existe no catálogo.


# TODO 2. Crie total = Decimal("0.00") e percorra a comanda somando.
#         Item fora da tabela: avise na tela e siga com continue.


# TODO 3. Aplique a regra chata da sua equipe.
#         Na barbearia: 10 por cento a partir de três itens.


# TODO 4. Imprima quantidade, itens distintos, subtotal, desconto e total.
#         Dica: sorted(set(comanda)) para os distintos.


# TODO 5. Olhe a saída com atenção. A quantidade de itens bate
#         com a quantidade de itens que foram COBRADOS?
#         Anote a sua resposta aqui:
