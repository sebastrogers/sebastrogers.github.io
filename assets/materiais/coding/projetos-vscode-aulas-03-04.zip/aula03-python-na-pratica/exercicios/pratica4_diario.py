"""Prática 4: dicionário com lista dentro.  (15 min)

Rode com:  python pratica4_diario.py
"""

# TODO 0. Monte um dicionário turma com:
#         Ana [8.0, 9.5], Bruno [6.0, 5.5] e Carla [4.0, 3.5].


# TODO 1. Crie uma lista vazia chamada medias.


# TODO 2. Percorra o dicionário com .items() e, para cada aluno:
#         calcule a média, guarde em medias, e defina a situação
#         (>= 7 Aprovado, >= 5 Recuperação, abaixo disso Reprovado).


# TODO 3. Imprima nome, média com uma casa e situação, alinhados.
#         Dica de alinhamento: f"{nome:<8}"


# TODO 4. Imprima a média da turma com duas casas.


# TODO 5. Extra: use sorted para listar da maior média para a menor.
