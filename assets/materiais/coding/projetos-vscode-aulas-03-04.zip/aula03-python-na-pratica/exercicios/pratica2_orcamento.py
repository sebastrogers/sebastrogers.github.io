"""Prática 2: leitura do teclado e conversão de tipo.  (10 min)

Teste com preço 19.90 e quantidade 3.
Rode com:  python pratica2_orcamento.py
"""

# TODO 0. Leia o preço unitário do teclado, como float.


# TODO 1. Leia a quantidade do teclado, como int.


# TODO 2. Calcule o total e aplique 10 por cento de desconto.


# TODO 3. Imprima preco * qtd SEM formatação.
#         Anote o que apareceu.


# TODO 4. Imprima o total com desconto usando f-string
#         e duas casas decimais.
