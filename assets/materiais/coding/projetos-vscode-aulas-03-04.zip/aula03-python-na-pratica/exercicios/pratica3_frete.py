"""Prática 3: estruturas condicionais.  (12 min)

Regra de frete:
  com cupom, ou acima de R$ 300  -> frete zero
  de R$ 100 até R$ 300           -> R$ 8
  abaixo de R$ 100               -> R$ 15

Rode com:  python pratica3_frete.py
"""

# TODO 0. Leia o valor da compra como float.


# TODO 1. Leia se o cliente tem cupom, respondendo s ou n.
#         Dica: normalize com .lower() antes de comparar.


# TODO 2. Decida o frete com if, elif e else, seguindo a regra acima.


# TODO 3. Imprima o frete e o total, os dois com duas casas.
