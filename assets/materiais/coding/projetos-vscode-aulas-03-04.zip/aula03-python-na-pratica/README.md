# Aula 3: Python na prática

**Coding: Linguagens e Técnicas** · 25/08/2026 · Prof. Sebastião Rogério

Variáveis, tipos, condicionais e coleções de dados.

## Como abrir

1. Abra esta pasta no VS Code: `Arquivo > Abrir Pasta`
2. Instale a extensão Python quando o VS Code sugerir
3. Selecione o interpretador: `Cmd+Shift+P` → `Python: Select Interpreter` → Python 3.12

## Como rodar

No terminal integrado (`Ctrl+'`):

```
python codigo/pratica1_variaveis.py
```

Ou abra o arquivo e aperte o botão de play no canto superior direito.

## O que tem aqui

```
codigo/        os arquivos prontos, do jeito que aparecem nos slides
exercicios/    os mesmos exercícios em branco, com TODO, para a turma
```

| Arquivo | Assunto |
|---|---|
| `pratica1_variaveis.py` | Atribuição múltipla, troca de valores, tipagem dinâmica |
| `pratica2_orcamento.py` | Leitura do teclado e conversão de tipo |
| `pratica2b_decimal.py` | O erro do ponto flutuante e a correção com Decimal |
| `pratica3_frete.py` | Condicionais com if, elif e else |
| `pratica4_diario.py` | Dicionário com lista dentro |
| `pratica5_comanda.py` | Tudo junto, no domínio da equipe |
| `pegadinhas.py` | Todas as armadilhas projetadas em aula, em um arquivo só |

## Entrega

Pasta `aula03` no repositório da equipe, com as cinco práticas resolvidas:

```
git status
git add aula03/pratica1_variaveis.py
git add aula03/pratica2_orcamento.py
git add aula03/pratica3_frete.py
git add aula03/pratica4_diario.py
git add aula03/pratica5_comanda.py
git commit -m "aula03: praticas de variaveis, tipos e colecoes"
git push origin main
```

## Um defeito de propósito

A `pratica5_comanda.py` cobra três serviços e informa quatro itens.
Não é erro de digitação. É defeito de regra de negócio, roda sem
mensagem nenhuma, e é corrigido na Aula 4.
