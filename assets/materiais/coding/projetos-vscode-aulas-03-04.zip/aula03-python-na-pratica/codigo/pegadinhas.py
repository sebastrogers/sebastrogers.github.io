"""As pegadinhas projetadas em aula, todas em um arquivo só.

Rode com:  python pegadinhas.py
"""

print("--- input devolve texto")
idade = "21"          # é o que input() teria devolvido
print(type(idade))
# print(idade + 1)    # TypeError: descomente para ver

print("\n--- conversão")
print(int("3"))
print(int(3.9))       # trunca, não arredonda
# print(int("3.5"))   # ValueError: descomente para ver

print("\n--- valores falsos")
for v in (0, "", [], "0", " ", "False"):
    print(repr(v), "->", bool(v))

print("\n--- o ou que não distribui")
resposta = "n"
print(resposta == "s" or "S")      # True, e está errado
print(resposta in ("s", "S"))      # False, e está certo

print("\n--- atribuir nunca copia")
turma_a = ["Ana", "Bruno"]
turma_b = turma_a
turma_b.append("Carla")
print(turma_a, turma_a is turma_b)

turma_a = ["Ana", "Bruno"]
turma_b = turma_a.copy()
turma_b.append("Carla")
print(turma_a, turma_b)

print("\n--- quem cria a tupla é a vírgula")
print(type(("Coding")))
print(type(("Coding",)))

print("\n--- append x extend")
a = [1, 2]
a.append([3, 4])
b = [1, 2]
b.extend([3, 4])
print(a, b)
