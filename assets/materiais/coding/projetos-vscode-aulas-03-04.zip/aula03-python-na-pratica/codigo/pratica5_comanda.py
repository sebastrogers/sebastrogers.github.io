"""Prática 5: a comanda do domínio da equipe.

Junta dicionário, lista, laço, condicional e Decimal.
Troque o catálogo pelo domínio da SUA equipe.

Rode com:  python pratica5_comanda.py
"""

from decimal import Decimal

precos = {
    "corte": Decimal("35.00"),
    "barba": Decimal("25.00"),
    "sobrancelha": Decimal("15.00"),
    "hidratação": Decimal("40.00"),
}

comanda = ["corte", "barba", "corte", "pintura"]

total = Decimal("0.00")

for item in comanda:
    if item not in precos:
        print(f"item fora da tabela: {item}")
        continue
    total += precos[item]

if len(comanda) >= 3:
    desconto = total * Decimal("0.10")
else:
    desconto = Decimal("0.00")

print(f"Itens:     {len(comanda)}")
print(f"Distintos: {sorted(set(comanda))}")
print(f"Subtotal:  R$ {total:.2f}")
print(f"Desconto:  R$ {desconto:.2f}")
print(f"Total:     R$ {total - desconto:.2f}")

# ATENÇÃO, defeito proposital:
# a conta cobrou 3 serviços e a tela informou 4 itens.
# O programa roda, não dá erro, e o cliente reclama no caixa.
# Este defeito é corrigido na Aula 4.
