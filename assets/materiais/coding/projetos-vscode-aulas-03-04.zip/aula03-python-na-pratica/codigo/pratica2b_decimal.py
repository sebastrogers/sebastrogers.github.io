"""Complemento da Prática 2: por que dinheiro não se guarda em float.

Rode com:  python pratica2b_decimal.py
"""

from decimal import Decimal

# o clássico
print(0.1 + 0.2)
print(0.1 + 0.2 == 0.3)

# dez moedas de dez centavos deveriam dar um real
total = 0.0
for _ in range(10):
    total += 0.1
print(total)

# a mesma conta em base 10
print(Decimal("0.1") + Decimal("0.2"))
print(Decimal("0.1") + Decimal("0.2") == Decimal("0.3"))

# ATENÇÃO: Decimal recebe TEXTO. Decimal(0.1) já nasce com o erro embutido.
print(Decimal(0.1))
