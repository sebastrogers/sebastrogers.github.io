"""Prática 3: escreva os testes das suas funções.  (20 min)

Rode com:  python -m pytest -q
Só continue quando as cinco linhas estiverem verdes.
"""

from decimal import Decimal

from comanda import fechar, itens_validos, subtotal


def test_subtotal_soma_apenas_o_que_esta_no_catalogo():
    # TODO 0. Uma comanda com dois itens válidos e um inválido.
    #         Confira o subtotal esperado.
    ...


def test_item_fora_do_catalogo_nao_conta_para_o_desconto():
    # TODO 1. Comanda com 3 itens, sendo 1 fora do catálogo.
    #         O desconto tem que ser zero.
    ...


def test_desconto_a_partir_de_tres_itens():
    # TODO 2. A regra chata da sua equipe, no valor EXATO da fronteira.
    ...


def test_comanda_vazia_nao_quebra():
    # TODO 3. Comanda vazia. O total tem que ser zero, sem erro.
    ...


def test_itens_validos_ignora_desconhecido():
    # TODO 4. itens_validos deve devolver só o que existe no catálogo.
    ...
