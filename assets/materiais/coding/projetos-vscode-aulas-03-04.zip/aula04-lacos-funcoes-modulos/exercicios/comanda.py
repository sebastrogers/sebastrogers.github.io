"""Prática 2: extraia as funções da comanda.  (20 min)

Nenhuma função pode ter print dentro. Quem imprime é quem chama.
Corrija aqui o defeito da Aula 3: o desconto deve olhar
apenas para os itens VÁLIDOS.

Rode direto:  python comanda.py
Rode testes:  python -m pytest -q
"""

from decimal import Decimal

# TODO 0. Traga o catálogo da SUA equipe para cá, como constante.
PRECOS = {
    "corte": Decimal("35.00"),
    "barba": Decimal("25.00"),
    "sobrancelha": Decimal("15.00"),
    "hidratacao": Decimal("40.00"),
}


def itens_validos(comanda, precos=PRECOS):
    """Devolve apenas os itens que existem no catálogo."""
    # TODO 1. Monte uma lista nova com os itens que estão em precos.
    ...


def subtotal(comanda, precos=PRECOS):
    """Soma o preço dos itens válidos."""
    # TODO 2. Comece com Decimal("0.00") e some usando itens_validos.
    ...


def desconto(comanda, valor, minimo=3):
    """Desconto conforme a regra da sua equipe."""
    # TODO 3. Aplique a regra olhando o TAMANHO DE itens_validos,
    #         e não o tamanho da comanda inteira.
    ...


def fechar(comanda):
    """Devolve um dicionário com subtotal, desconto e total."""
    # TODO 4. Use as três funções acima.
    ...


if __name__ == "__main__":
    conta = fechar(["corte", "barba", "corte", "pintura"])
    for chave, valor in conta.items():
        print(f"{chave:<9} R$ {valor:.2f}")
