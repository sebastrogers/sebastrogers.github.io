"""Prática 1: laços.  (10 min)

Rode com:  python pratica1_lacos.py
"""

servicos = ["corte", "barba", "sobrancelha", "hidratacao"]
precos = {"corte": 35, "barba": 25, "sobrancelha": 15, "hidratacao": 40}
comanda = ["corte", "barba", "corte", "pintura"]

# TODO 0. Percorra servicos com for e imprima cada um.


# TODO 1. Imprima a mesma lista numerada a partir de 1, com enumerate.


# TODO 2. Some com um for os preços dos itens da comanda
#         que existem no dicionário precos. Imprima o total.


# TODO 3. Usando while, descubra quantos cortes de R$ 35
#         cabem em R$ 200. Imprima a quantidade e o que sobrou.


# TODO 4. Percorra a comanda e imprima apenas os itens
#         que estão no catálogo, usando continue para pular os outros.
