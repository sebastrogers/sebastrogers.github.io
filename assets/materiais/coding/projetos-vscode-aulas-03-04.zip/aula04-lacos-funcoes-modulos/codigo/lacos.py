"""Os laços projetados em aula.

Rode com:  python lacos.py
"""

print("--- for percorre a coleção, não o índice")
servicos = ["corte", "barba", "sobrancelha"]
for servico in servicos:
    print(servico)

print("\n--- range: o começo entra, o fim não")
for i in range(5):
    print(i, end=" ")
print()
print(list(range(1, 6)))
print(list(range(0, 10, 2)))

print("\n--- enumerate: item e posição de uma vez")
for i, servico in enumerate(servicos, start=1):
    print(i, servico)

print("\n--- PEGADINHA: alterar a lista enquanto percorre")
itens = ["corte", "pintura", "tintura", "barba"]
for item in itens:
    if item not in ("corte", "barba"):
        itens.remove(item)
print("errado:", itens)          # sobra tintura, e ninguém avisa

print("\n--- a correção: monte uma lista nova")
itens = ["corte", "pintura", "tintura", "barba"]
limpos = []
for item in itens:
    if item in ("corte", "barba"):
        limpos.append(item)
print("certo: ", limpos)

print("\n--- while: repete enquanto a condição for verdadeira")
saldo = 100
dias = 0
while saldo >= 35:
    saldo -= 35
    dias += 1
print(dias, saldo)

print("\n--- continue pula a volta")
for item in ["corte", "pintura", "barba"]:
    if item == "pintura":
        print("fora do catalogo, ignorando")
        continue
    print("cobrando", item)
