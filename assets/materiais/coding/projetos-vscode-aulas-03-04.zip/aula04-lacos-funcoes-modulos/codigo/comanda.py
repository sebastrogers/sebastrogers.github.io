"""Módulo da comanda: as funções do domínio, sem nenhum print dentro.

Rode direto para ver um exemplo:  python comanda.py
Rode os testes:                   python -m pytest -q
"""

from decimal import Decimal

PRECOS = {
    "corte": Decimal("35.00"),
    "barba": Decimal("25.00"),
    "sobrancelha": Decimal("15.00"),
    "hidratacao": Decimal("40.00"),
}


def itens_validos(comanda, precos=PRECOS):
    """Devolve apenas os itens que existem no catálogo."""
    validos = []
    for item in comanda:
        if item in precos:
            validos.append(item)
    return validos


def subtotal(comanda, precos=PRECOS):
    """Soma o preço dos itens válidos."""
    total = Decimal("0.00")
    for item in itens_validos(comanda, precos):
        total += precos[item]
    return total


def desconto(comanda, valor, minimo=3):
    """10% a partir de `minimo` itens VÁLIDOS.

    Aqui está a correção do defeito da Aula 3: antes a condição
    usava len(comanda), que contava também o que não foi cobrado.
    """
    if len(itens_validos(comanda)) >= minimo:
        return valor * Decimal("0.10")
    return Decimal("0.00")


def fechar(comanda):
    """Devolve subtotal, desconto e total da comanda."""
    sub = subtotal(comanda)
    desc = desconto(comanda, sub)
    return {"subtotal": sub, "desconto": desc, "total": sub - desc}


if __name__ == "__main__":
    conta = fechar(["corte", "barba", "corte", "pintura"])
    for chave, valor in conta.items():
        print(f"{chave:<9} R$ {valor:.2f}")
