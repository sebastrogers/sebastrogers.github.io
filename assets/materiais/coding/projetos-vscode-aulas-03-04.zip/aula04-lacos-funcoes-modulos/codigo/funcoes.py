"""As funções projetadas em aula, com as duas pegadinhas.

Rode com:  python funcoes.py
"""

print("--- def, parâmetro e retorno")


def preco_com_desconto(preco, percentual=10):
    return preco - (preco * percentual / 100)


print(preco_com_desconto(35))
print(preco_com_desconto(35, 20))
print(preco_com_desconto(preco=35, percentual=50))

print("\n--- função sem return devolve None")


def mostrar(nome):
    print(f"Servico: {nome}")


x = mostrar("corte")
print(x)
print(type(x))

print("\n--- PEGADINHA: valor padrão mutável")


def registrar_errado(item, comanda=[]):
    comanda.append(item)
    return comanda


print(registrar_errado("corte"))
print(registrar_errado("barba"))
print(registrar_errado("sobrancelha"))

print("\n--- a correção: None como marcador")


def registrar(item, comanda=None):
    if comanda is None:
        comanda = []
    comanda.append(item)
    return comanda


print(registrar("corte"))
print(registrar("barba"))

print("\n--- PEGADINHA: escopo")

total = 0


def somar_errado(valor):
    total = total + valor    # vira local, e ainda não tem valor
    return total


try:
    print(somar_errado(35))
except UnboundLocalError as erro:
    print("UnboundLocalError:", erro)

print("\n--- a correção: entra por parâmetro, sai por return")


def somar(total, valor):
    return total + valor


acumulado = 0
acumulado = somar(acumulado, 35)
acumulado = somar(acumulado, 25)
print(acumulado)
