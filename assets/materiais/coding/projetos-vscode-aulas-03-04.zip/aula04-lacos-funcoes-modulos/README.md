# Aula 4: Laços, funções e módulos

**Coding: Linguagens e Técnicas** · 01/09/2026 · Prof. Sebastião Rogério

Laços, funções, separação em módulos e a primeira suíte de testes.

## Como abrir

1. Abra esta pasta no VS Code: `Arquivo > Abrir Pasta`
2. Instale a extensão Python quando o VS Code sugerir
3. Selecione o interpretador: `Cmd+Shift+P` → `Python: Select Interpreter` → Python 3.12

## Ambiente e dependências

```
python -m venv .venv
source .venv/bin/activate        # no Windows: .venv\Scripts\activate
pip install -r codigo/requirements.txt
```

## Como rodar

```
python codigo/lacos.py
python codigo/funcoes.py
python codigo/comanda.py
```

Os testes, de dentro da pasta:

```
cd codigo
python -m pytest -q
```

O VS Code também mostra os testes no ícone de frasco na barra lateral.
Já deixei o pytest habilitado em `.vscode/settings.json`.

## O que tem aqui

```
codigo/        os arquivos prontos, do jeito que aparecem nos slides
exercicios/    os mesmos exercícios em branco, com TODO, para a turma
```

| Arquivo | Assunto |
|---|---|
| `lacos.py` | for, range, enumerate, while, continue e a armadilha do remove |
| `funcoes.py` | def, return, valor padrão mutável e escopo |
| `comanda.py` | O módulo do domínio, sem nenhum print dentro |
| `test_comanda.py` | Cinco testes, cinco regras de negócio |

## O defeito da Aula 3, e como vê-lo falhar

Em `comanda.py`, troque a linha do desconto por:

```python
if len(comanda) >= minimo:          # errado, conta item não cobrado
```

Rode `python -m pytest -q` e observe:

```
E  AssertionError: assert Decimal('6.0000') == Decimal('0.00')
1 failed, 4 passed
```

Depois volte para a versão correta:

```python
if len(itens_validos(comanda)) >= minimo:
```

Esse é o ponto da aula: o teste encontra o defeito sozinho, toda vez.

## Entrega

Pasta `aula04` no repositório da equipe, com a suíte verde:

```
git status
git add aula04/comanda.py
git add aula04/test_comanda.py
git commit -m "aula04: extrai funcoes da comanda e adiciona testes"
git push origin main
```

Não envie `__pycache__/` nem `.pytest_cache/`. O `.gitignore` já cuida disso.
